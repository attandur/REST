package BasicRestAPIs;

import org.testng.annotations.Test;


import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class JSONPathUsage {
	
	@Test(enabled = true)
	public void POST() {
		
		RestAssured.baseURI="http://localhost:3000";
		Response resp2 = RestAssured.get("http://localhost:3000/Food");
		System.out.println(resp2.asString());
		
		JsonPath obj = new JsonPath(resp2.asString());
		int ArraySize= obj.getInt("Food.size()");
        System.out.println("Number of Objects " + ArraySize);
       // System.out.println(obj.getString("Food"));
        System.out.println(obj.getString("fruits[2]"));
        System.out.println(obj.getString("vegetables[1].veggieName"));
        //System.out.println(obj);


}
}
