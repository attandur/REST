package BasicRestAPIs;

import java.util.ArrayList;

import java.util.HashMap;
import java.util.List;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DATAReadingFromHashMap {
	
	@Test(enabled = true)
	public void POST() {
		
		ArrayList<String> fruitsList = new ArrayList<String>();
		fruitsList.add("Dragon12");
		fruitsList.add("Papaya23");

	
		ArrayList<String> vegetablesList1 = new ArrayList<String>();
		vegetablesList1.add("Ladyfinger12");
		vegetablesList1.add("true");
		
		ArrayList<String> vegetablesList2 = new ArrayList<String>();
		vegetablesList2.add("Onion12");
		vegetablesList2.add("false");
		
		HashMap<String, List<String>> hm = new HashMap<String, List<String>>();
        hm.put("fruits", fruitsList);
        hm.put("vegetables", vegetablesList1);
        hm.put("vegetables", vegetablesList2);

		
		RestAssured.baseURI = "http://localhost:3000";
		RestAssured.given().log().all().body(hm)
				// Giving header details are important
				.header("Content-Type", "application/json").when().post("/Food");
		Response resp2 = RestAssured.get("http://localhost:3000/Food/5");
		System.out.println(resp2.asString());
	}
}