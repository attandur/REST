package BasicRestAPIs;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DATAReadingFromJSONFile {
	
	@Test(enabled = true)
	public void POST() {
		
		RestAssured.baseURI="http://localhost:3000";
		RestAssured.given().log().all().body(new File("./Data.json"))
		   .header("Contenty-Type","application/json").when().post("/Food");
		Response resp2 = RestAssured.get("http://localhost:3000/Food");
		System.out.println(resp2.asString());
		
	}

}
