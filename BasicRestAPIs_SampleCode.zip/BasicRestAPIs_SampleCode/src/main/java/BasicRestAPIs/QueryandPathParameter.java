package BasicRestAPIs;

import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class QueryandPathParameter {
	
	@Test(enabled = false)
	public void QueryParameter()
	{	
		Response resp = RestAssured.given().queryParam("id", "3").header("Content-Type", "application/json").get("http://localhost:3000/Food");
				
		System.out.println(resp.asString());
		System.out.println("********************************************************************");
		System.out.println("The status Code is :" + resp.statusCode());
		System.out.println("The status response line s :" + resp.statusLine());
		System.out.println("********************************************************************");	
	} 
	
	@Test(enabled = true)
	public void PathParameter()
	{	
		Response resp = RestAssured.given().header("Content-Type", "application/json").get("http://localhost:3000/Food/3");
				
		System.out.println(resp.asString());
		System.out.println("********************************************************************");
		System.out.println("The status Code is :" + resp.statusCode());
		System.out.println("The status response line s :" + resp.statusLine());
		System.out.println("********************************************************************");	
	} 
}
