package BasicRestAPIs;

public class POJOClass {
	
	private String title;
	private String author;
	private String id;
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getAuthor() {
		return author;
	}
	
	public void setAuthor(String author) {
		this.author = author;
	}
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}

	public static void ToString(POJOClass obj)
	
	{
		System.out.println(obj.getTitle());
		System.out.println(obj.getAuthor());
		System.out.println(obj.getId());
		
	}
}
