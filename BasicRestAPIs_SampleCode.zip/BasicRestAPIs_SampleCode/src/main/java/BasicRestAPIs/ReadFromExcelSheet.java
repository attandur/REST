package BasicRestAPIs;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.Assert;

public class ReadFromExcelSheet {

	public static void main(String[] args) throws IOException {
		String pathofExcelSheet = "/Users/anil/Documents/Food.xlsx";
		File file = new File(pathofExcelSheet);
		FileInputStream fis = new FileInputStream(file);
		
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheetOfInterest = wb.getSheet("Sheet1");
		XSSFRow row1 = sheetOfInterest.getRow(1);
		XSSFRow row2 = sheetOfInterest.getRow(2);
		XSSFRow row3 = sheetOfInterest.getRow(3);

		System.out.println(row1.getCell(2).getStringCellValue());
		Assert.assertEquals(row1.getCell(2).getStringCellValue(), "orange");
		System.out.println(row2.getCell(1).getStringCellValue().toString());
		Assert.assertEquals(row2.getCell(1).getStringCellValue(), "potato");
		System.out.println(row3.getCell(1).getBooleanCellValue());
		Assert.assertEquals(row3.getCell(1).getBooleanCellValue(), true);
	}

}
