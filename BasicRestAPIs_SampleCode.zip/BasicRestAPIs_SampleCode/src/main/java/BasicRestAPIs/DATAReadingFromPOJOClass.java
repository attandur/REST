package BasicRestAPIs;

import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DATAReadingFromPOJOClass {
	
@Test(enabled = true)
	public void POST() throws JsonProcessingException {
		RestAssured.baseURI = "http://localhost:3000";
		// Reading the data from POJO Class for the payload details
		POJOClass objPojo = new POJOClass();
		objPojo.setAuthor("VIP3");
		objPojo.setTitle("Sonia");
				
		// Object Mapper
		ObjectMapper mapper = new ObjectMapper();
		String jsonBodyData = mapper.writeValueAsString(objPojo);
		
		RestAssured.given().log().all().body(jsonBodyData)
				// Giving header details are important
				.header("Content-Type", "application/json").when().post("/posts");
		Response resp2 = RestAssured.get("http://localhost:3000/posts");
		System.out.println(resp2.asString());
		


//Deserializaion code
POJOClass objPojo2 =RestAssured.given().get("http://localhost:3000/posts/1").as(POJOClass.class);
POJOClass.ToString(objPojo2);

}
}
		
